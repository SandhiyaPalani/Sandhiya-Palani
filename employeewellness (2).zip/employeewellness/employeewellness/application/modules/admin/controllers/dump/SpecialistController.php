<?php

class SpecialistController extends Zend_Controller_Action
{
	protected $_redirector = null;
	protected $_dbAdapter = null;
    
	public function init()
    {
		$registry = Zend_Registry::getInstance();
		$this->_dbAdapter = $registry->dbAdapter;
        $this->_redirector = $this->_helper->getHelper('Redirector');

        if (empty($this->view->adminidentity)) {
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
	    } else {
			$identity = $this->view->adminidentity;
			$userType = $identity->userType;
			if($userType != 'D') {								
				Default_Models_AdminAuth::destroy();
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
			}
		}
	
	}

    public function indexAction()
    {	
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';		
		
		#Getting doctors info
		$where = " AND ap.status = 'Pending' AND d.adminid = ".$this->view->adminidentity->userId;
		$row =  $commonobj->getMyappointments($where);		
		//print_r($row); exit;
		
		#Setting data to view page
		$this->view->row = $row;	
		$this->view->profileaction = "Manage Appointments";
		$this->view->errormsg = $errormsg;	
		$this->view->msg = $_GET['msg'];
    }
	
	public function myappointmentsAction()
	{
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';		
		
		#Getting doctors info
		$where = " AND ad.userId = ".$this->view->adminidentity->userId." AND ap.status Not LIKE 'Pending'";
		$row =  $commonobj->getMyappointments($where);		
		//print_r($row); exit;
		
		#Setting data to view page
		$this->view->row = $row;	
		$this->view->profileaction = "My Appointments";
		$this->view->errormsg = $errormsg;
		$this->view->msg = $_GET['msg'];
	}
	
	public function approveAction(){
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Disable layout
		$this->_helper->layout()->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		
		if(isset($_GET['rowid']) && $_GET['rowid'] != ""){
			#Getting Objects
			$commonobj = new Default_Models_Common();
		
			#Getting users list
			$info = array("status" => "Approve");
			$commonobj->updateAppointments($info, $_GET['rowid']);
			
			//Sendemail
			#Getting doctors info
			$where = " AND ap.bookid = ".$_GET['rowid'];
			$bookinfo =  $commonobj->getMyappointments($where);	
			$fullname = ucfirst($bookinfo[0]->doctorfname)." ".ucfirst($bookinfo[0]->doctorlname);
			$emailinfo = array(
				"fromemail" => $commonobj->getAESCryptData($bookinfo[0]->doctoremail, 'decrypt'),
				"fromname" =>$fullname,
				"toemail" =>$commonobj->getAESCryptData($bookinfo[0]->patientemail, 'decrypt'),#$this->view->testemail,#
				"subject" =>"Your appointment on ".$bookinfo[0]->appointmentdate." was Approved",
				"texthtml" =>"Dear <strong>Patient</strong>,<br><br>Your appointment on ".$bookinfo[0]->appointmentdate." was Approved. Appointment details<br><br>
										<strong>Patient code :</strong> ".$bookinfo[0]->patientcode."<br>
										<strong>Patient name :</strong> ".ucfirst($bookinfo[0]->patientfname)." ".ucfirst($bookinfo[0]->patientlname)."<br>
										<strong>Appointment date :</strong> ".$bookinfo[0]->appointmentdate." ".$bookinfo[0]->appointmenttime."<br>
										<strong>Reason :</strong> ".nl2br($bookinfo[0]->reason)."<br><br>
										Regards,<br>
										<strong>Health Care Admin</strong>",
			 );
			$output = $commonobj->sendtestemail($emailinfo);		
			
			$this->_redirector->gotoSimple('myappointments','specialist','admin', array('msg' => 'Appointment_Approved_Successfully'));
		}
		echo "<br>==========>RowId Not Found";
		exit;	
		
	}	
	
	public function cancelAction(){
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Disable layout
		$this->_helper->layout()->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		
		if(isset($_GET['rowid']) && $_GET['rowid'] != ""){
			#Getting Objects
			$commonobj = new Default_Models_Common();
		
			#Getting users list
			$info = array("status" => "Canceled");
			$commonobj->updateAppointments($info, $_GET['rowid']);
			
			//Sendemail
			#Getting doctors info
			$where = " AND ap.bookid = ".$_GET['rowid'];
			$bookinfo =  $commonobj->getMyappointments($where);	
			$fullname = ucfirst($bookinfo[0]->doctorfname)." ".ucfirst($bookinfo[0]->doctorlname);
			$emailinfo = array(
				"fromemail" => $commonobj->getAESCryptData($bookinfo[0]->doctoremail, 'decrypt'),
				"fromname" =>$fullname,
				"toemail" =>$commonobj->getAESCryptData($bookinfo[0]->patientemail, 'decrypt'),#$this->view->testemail,#
				"subject" =>"Your appointment on ".$bookinfo[0]->appointmentdate." was Canceled",
				"texthtml" =>"Dear <strong>Patient</strong>,<br><br>Your appointment on ".$bookinfo[0]->appointmentdate." was Canceled. Kindly make an new appoint on some other days.<br><br>
										Regards,<br>
										<strong>Health Care Admin</strong>",
			 );
			$output = $commonobj->sendtestemail($emailinfo);
			
			$this->_redirector->gotoSimple('myappointments','specialist','admin', array('msg' => 'Appointment_Canceled_Successfully'));
		}
		echo "<br>==========>RowId Not Found";
		exit;	
		
	}		

    public function closeAction()
    {	
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';		
		
		if(!isset($_GET['rowid']) || empty($_GET['rowid'])) {
			$this->_redirector->gotoSimple('index','patient','admin',  array('msg' => ''));
		}
		
		#Getting doctors info
		$where = " AND ap.bookid = ".$_GET['rowid'];
		$bookinfo =  $commonobj->getMyappointments($where);	
		
		
		#POST Process
		if($this->getRequest()->isPost()) {			
			#Getting users list
			$info = array("status" => $_POST['status'], "comments" => $_POST['comments']);
			$commonobj->updateAppointments($info, $_GET['rowid']);
			
			//Sendemail
			#Getting Book info
			$where = " AND ap.bookid = ".$_GET['rowid'];
			$bookinfo =  $commonobj->getMyappointments($where);	
			$fullname = ucfirst($bookinfo[0]->patientfname)." ".ucfirst($bookinfo[0]->patientlname);
			
			if($_POST['status'] == "Canceled") {
				$subject = "Your appointment on ".$bookinfo[0]->appointmentdate." was Canceled";
				$content = "Dear <strong>Patient</strong>,<br><br>Your appointment on ".$bookinfo[0]->appointmentdate." was Canceled. Kindly make an new appoint on some other days.<br><br>
				<strong>Comments :</strong> ".nl2br($bookinfo[0]->comments)."<br><br>
										Regards,<br>
										<strong>Health Care Admin</strong>";
			} else {
				$subject = "Your appointment on ".$bookinfo[0]->appointmentdate." was Closed";
				$content = "Dear <strong>Patient</strong>,<br><br>Your appointment closed and appointment details are<br><br>
										<strong>Doctor code :</strong> ".$bookinfo[0]->doctorcode."<br>
										<strong>Doctor name :</strong> ".ucfirst($bookinfo[0]->doctorfname)." ".ucfirst($bookinfo[0]->doctorlname)."<br>
										<strong>Patient code :</strong> ".$bookinfo[0]->patientcode."<br>
										<strong>Patient name :</strong> ".$fullname."<br>
										<strong>Appointment date :</strong> ".$bookinfo[0]->appointmentdate." ".$bookinfo[0]->appointmenttime."<br>
										<strong>Reason :</strong> ".nl2br($bookinfo[0]->reason)."<br>
										<strong>Comments :</strong> ".nl2br($bookinfo[0]->comments)."<br><br>
										Regards,<br>
										<strong>Health Care Admin</strong>";
			}
			
			
			$emailinfo = array(
				"fromemail" => $commonobj->getAESCryptData($bookinfo[0]->patientemail, 'decrypt'),
				"fromname" => $fullname,
				"toemail" => $commonobj->getAESCryptData($bookinfo[0]->patientemail, 'decrypt'),#$this->view->testemail,#
				"subject" => $subject,
				"texthtml" => $content,
			 );
			//echo "<pre>"; print_r($emailinfo); exit;
			$output = $commonobj->sendtestemail($emailinfo);
			
			$this->_redirector->gotoSimple('myappointments','specialist','admin',  array('msg' => 'Appointment_updated_successfully'));			
		}
		
		#Setting data to view page
		$this->view->profileaction = "Book";
		$this->view->form = $form;
		$this->view->row = $bookinfo;
		$this->view->errormsg = $errormsg;
    }	
	
	public function myaccountAction()
	{
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$form    = new Default_Form_DoctorsForm();
		$doctors = new Default_Models_Doctors();
		$commonobj = new Default_Models_Common();
		
		#Getting doctors info
		$where = " AND d.adminid = ".$this->view->adminidentity->userId;
		$row =  $commonobj->getDoctors($where);
		$doctorinfo = $row[0];
		
		#variables
		$errormsg = '';		
		
		#POST Process
		if($this->getRequest()->isPost()) {
			if($form->isValid($request->getPost())){
				$_POST['adminid'] = $doctorinfo->adminid;
				$_POST['usercode'] = $doctorinfo->usercode;
				//echo "<pre>"; print_r($_POST); exit;
				#Check for username exist
				$where = " AND (aadhar LIKE '".$commonobj->getAESCryptData(trim($_POST['aadhar']))."'  OR email LIKE '".$commonobj->getAESCryptData(trim($_POST['email']))."') AND doctorid != ".$_POST['doctorid'];
				if($commonobj->getDoctors($where)) {
					$errormsg = "Aadhar or Email already exist";
				} else {
				
					$insertData = new Default_Models_Doctors($_POST);
					$insertData->save();				
					$this->_redirector->gotoSimple('index','specialist','admin', array('msg' => 'Updated_Successfully'));
				}
			}
		}
		
		#Setting data to view page
		$this->view->row = $doctorinfo;	
		$this->view->form = $form;		
		$this->view->profileaction = "edit";
		$this->view->errormsg = $errormsg;
	}
	
}