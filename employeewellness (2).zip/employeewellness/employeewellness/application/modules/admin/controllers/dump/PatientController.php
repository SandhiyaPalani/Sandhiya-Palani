<?php

class PatientController extends Zend_Controller_Action
{
	protected $_redirector = null;
	protected $_dbAdapter = null;
    
	public function init()
    {
		$registry = Zend_Registry::getInstance();
		$this->_dbAdapter = $registry->dbAdapter;
        $this->_redirector = $this->_helper->getHelper('Redirector');

        if (empty($this->view->adminidentity)) {
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
	    } else {
			$identity = $this->view->adminidentity;
			$userType = $identity->userType;
			
			if($userType != 'U') {								
				Default_Models_AdminAuth::destroy();
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
			}
		}
	
	}

    public function indexAction()
    {
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#POST Process
		$searchTerm = $where = '';
		if($this->getRequest()->isPost()) {
			$searchTerm = trim($_POST['searchTerm']);
			if($searchTerm)
				$where = " AND s.specializationid = '".$searchTerm."'";
		}		
		
		#Getting users list
		$doctors =  $commonobj->getDoctors($where);
		
		#Setting data to view page
		$this->view->doctors = $doctors;
		$this->view->searchTerm = $searchTerm;
		$this->view->msg = $_GET['msg'];		
    }

    public function bookAction()
    {	
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';		
		
		#Getting doctors info
		$where = " AND d.doctorid = ".$_GET['rowid'];
		$row =  $commonobj->getDoctors($where);
		
		if(!isset($_GET['rowid']) || empty($_GET['rowid'])) {
			$this->_redirector->gotoSimple('index','patient','admin',  array('msg' => ''));
		}
		
		#POST Process
		if($this->getRequest()->isPost()) {			
			$_POST['doctorid'] = $row[0]->doctorid;
			$_POST['uid'] = $this->view->adminidentity->userId;
			$_POST['status'] = 'Pending';
			$bookid = $commonobj->bookAppointments($_POST);
			
			//Sendemail
			#Getting doctors info
			$where = " AND ap.bookid = ".$bookid;
			$bookinfo =  $commonobj->getMyappointments($where);	
			$fullname = ucfirst($bookinfo[0]->patientfname)." ".ucfirst($bookinfo[0]->patientlname);
			$emailinfo = array(
				"fromemail" => $commonobj->getAESCryptData($bookinfo[0]->patientemail, 'decrypt'),
				"fromname" =>$fullname,
				"toemail" =>$commonobj->getAESCryptData($bookinfo[0]->doctoremail, 'decrypt'),#$this->view->testemail,#
				"subject" =>"New Appointment Booking on ".$bookinfo[0]->appointmentdate." - ".$bookinfo[0]->patientcode,
				"texthtml" =>"Dear <strong>Doctor</strong>,<br><br>You are having new appointment pending for approval. Appointment details<br><br>
										<strong>Patient code :</strong> ".$bookinfo[0]->patientcode."<br>
										<strong>Patient name :</strong> ".$fullname."<br>
										<strong>Appointment date :</strong> ".$bookinfo[0]->appointmentdate." ".$bookinfo[0]->appointmenttime."<br>
										<strong>Reason :</strong> ".nl2br($bookinfo[0]->reason)."<br><br>
										Regards,<br>
										<strong>Health Care Admin</strong>",
			 );
			$output = $commonobj->sendtestemail($emailinfo);
			
			$this->_redirector->gotoSimple('myappointments','patient','admin',  array('msg' => 'Your_Appointment_Booked_successfully'));			
		}
		
		#Setting data to view page
		$this->view->profileaction = "Book";
		$this->view->form = $form;
		$this->view->row = $row;
		$this->view->errormsg = $errormsg;
    }	
	
	public function myaccountAction()
	{
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$form    = new Default_Form_UsersForm();
		$users = new Default_Models_Users();
		$commonobj = new Default_Models_Common();
		
		#Getting users info
		$where = " AND a.userId = ".$this->view->adminidentity->userId;
		$row =  $commonobj->getUsers($where);
		$userinfo = $row[0];
		
		#variables
		$errormsg = '';		
		
		#POST Process
		if($this->getRequest()->isPost()) {
			if($form->isValid($request->getPost())){
				$_POST['adminid'] = $userinfo->adminid;
				$_POST['usercode'] = $userinfo->usercode;
				//echo "<pre>"; print_r($_POST); exit;
				#Check for username exist
				$where = " AND (aadhar LIKE '".$commonobj->getAESCryptData(trim($_POST['aadhar']))."'  OR email LIKE '".$commonobj->getAESCryptData(trim($_POST['email']))."') AND uid != ".$_POST['uid'];
				if($commonobj->getUsers($where)) {
					$errormsg = "Aadhar or Email already exist";
				} else {
				
					$insertData = new Default_Models_Users($_POST);
					$insertData->save();				
					$this->_redirector->gotoSimple('index','patient','admin', array('msg' => 'Updated_Successfully'));
				}
			}
		}
		
		#Setting data to view page
		$this->view->row = $userinfo;	
		$this->view->form = $form;		
		$this->view->profileaction = "edit";
		$this->view->errormsg = $errormsg;
	}
	
	
	public function myappointmentsAction()
	{
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';		
		
		#Getting doctors info
		$where = " AND ap.uid = ".$this->view->adminidentity->userId;
		$row =  $commonobj->getMyappointments($where);		
		//print_r($row); exit;
		
		#Setting data to view page
		$this->view->row = $row;	
		$this->view->profileaction = "My Appointments";
		$this->view->errormsg = $errormsg;
		$this->view->msg = $_GET['msg'];
	}
}