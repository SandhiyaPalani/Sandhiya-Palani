<?php

class OnlinedoctorController extends Zend_Controller_Action
{
	protected $_redirector = null;
	protected $_dbAdapter = null;
    
	public function init()
    {
		$registry = Zend_Registry::getInstance();
		$this->_dbAdapter = $registry->dbAdapter;
        $this->_redirector = $this->_helper->getHelper('Redirector');
	}

    public function indexAction()
    {
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		$this->_helper->layout()->disableLayout();
		
		#POST Process
		$searchTerm = '';
		if($this->getRequest()->isPost()) {
			$searchTerm = trim($_POST['searchTerm']);
		}		
		
		#Setting data to view page
		$this->view->searchTerm = $searchTerm;
		$this->view->msg = $_GET['msg'];		
    }

    public function patientregisterAction()
    {	
		if (!empty($this->view->adminidentity)) {
			$this->_redirector->gotoSimple('index','onlinedoctor','admin');
			exit;
		}
	
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$form    = new Default_Form_UsersForm();
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';
		
		#POST Process
		if($this->getRequest()->isPost()) {			
			if($form->isValid($request->getPost())){
				$info['username'] = $commonobj->getUsername($_POST['firstname'], $_POST['lastname'], $_POST['aadhar']);
				$info['password'] = $commonobj->randomPassword();
				$_POST['adminid'] = $commonobj->insertAdminuser($info, 'U');
				$_POST['usercode'] = $info['username'];
				
				#Check for username exist
				$where = " AND (aadhar LIKE '".$commonobj->getAESCryptData(trim($_POST['aadhar']))."'  OR email LIKE '".$commonobj->getAESCryptData(trim($_POST['email']))."') ";
				if($commonobj->getUsers($where)) {
					$errormsg = "Aadhar or Email already exist";
				} else {
					$insertData = new Default_Models_Users($_POST);				
					$insertData->save();
					
					//Sendemail
					$emailinfo = array(
						"fromemail" => 'ihjeeva@gmail.com',
						"fromname" => 'Admin',
						"toemail" => $_POST['email'],# 
						"subject" =>"Welcome to Online Health Care - Patient",
						"texthtml" =>"Dear <strong>Admin</strong>,<br><br>Your login details are <br><br>
												<strong>Login URL :</strong> ".$this->view->httphost."/auth/index<br>
												<strong>Username :</strong> ".$info['username']."<br>
												<strong>Password :</strong> ".$info['password']."<br><br>
												Regards,<br>
												<strong>Health Care Admin</strong>",
					 );
					$output = $commonobj->sendtestemail($emailinfo);
					
					$this->_redirector->gotoSimple('patientregister','onlinedoctor','admin',  array('msg' => 'Registration_successful'));
				}
			}
		}
		
		#Setting data to view page
		$this->view->profileaction = "add";
		$this->view->form = $form;
		$this->view->errormsg = $errormsg;
		$this->view->msg = str_replace('_', ' ', $_GET['msg']);
    }	
}