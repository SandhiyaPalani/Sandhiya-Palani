<?php

class DoctorsController extends Zend_Controller_Action
{
	protected $_redirector = null;
	protected $_dbAdapter = null;
    
	public function init()
    {
		$registry = Zend_Registry::getInstance();
		$this->_dbAdapter = $registry->dbAdapter;
        $this->_redirector = $this->_helper->getHelper('Redirector');

        if (empty($this->view->adminidentity)) {
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
	    } else {
			$identity = $this->view->adminidentity;
			$userType = $identity->userType;
			if($userType != 'A') {								
				Default_Models_AdminAuth::destroy();
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
			}
		}
	
	}

    public function indexAction()
    {
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#POST Process
		$searchTerm = '';
		if($this->getRequest()->isPost()) {
			$searchTerm = trim($_POST['searchTerm']);
		}		
		
		#Getting doctors list
		$doctors =  $commonobj->getDoctors($searchTerm);
		
		#Setting data to view page
		$this->view->doctors = $doctors;
		$this->view->searchTerm = $searchTerm;
		$this->view->msg = $_GET['msg'];		
    }

    public function newAction()
    {	
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$form    = new Default_Form_DoctorsForm();
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';
		
		#POST Process
		if($this->getRequest()->isPost()) {			
			if($form->isValid($request->getPost())){
				$info['username'] = $commonobj->getUsername($_POST['firstname'], $_POST['lastname'], $_POST['aadhar']);
				$info['password'] = $commonobj->randomPassword();
				$_POST['adminid'] = $commonobj->insertAdminuser($info, 'D');
				$_POST['usercode'] = $info['username'];
				
				#Check for username exist
				$where = " AND (aadhar LIKE '".$commonobj->getAESCryptData(trim($_POST['aadhar']))."'  OR email LIKE '".$commonobj->getAESCryptData(trim($_POST['email']))."') ";
				if($commonobj->getUsers($where)) {
					$errormsg = "Aadhar or email already exist";
				} else {
					$insertData = new Default_Models_Doctors($_POST);				
					$insertData->save();
					
					//Sendemail
					$fullname = ucfirst($_POST['firstname'])." ".ucfirst($_POST['lastname']);
					$emailinfo = array(
						"fromemail" => "ihjeeva@gmail.com",
						"fromname" => $fullname,
						"toemail" => $_POST['email'],#$this->view->testemail,#$_POST['email']
						"subject" =>"Welcome to Online Health Care - Doctor",
						"texthtml" =>"Dear <strong>".$fullname."</strong>,<br><br>Your login details are <br><br>
												<strong>Login URL :</strong>".$this->view->httphost."<br>
												<strong>Username :</strong> ".$info['username']."<br>
												<strong>Password :</strong> ".$info['password']."<br><br>
												Regards,<br>
												<strong>Health Care Admin</strong>",
					 );
					$output = $commonobj->sendtestemail($emailinfo);
					
					$this->_redirector->gotoSimple('index','doctors','admin',  array('msg' => 'User_added_successfully'));
				}
			}
		}
		
		#Setting data to view page
		$this->view->profileaction = "add";
		$this->view->form = $form;
		$this->view->errormsg = $errormsg;
    }	
	
	public function editAction()
	{
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$form    = new Default_Form_DoctorsForm();
		$doctors = new Default_Models_Doctors();
		$commonobj = new Default_Models_Common();
		
		#Getting doctors info
		$row =  $doctors->find($_GET['rowid']);
		
		#variables
		$errormsg = '';		
		
		#POST Process
		if($this->getRequest()->isPost()) {
			if($form->isValid($request->getPost())){
				$_POST['adminid'] = $row->adminid;
				$_POST['usercode'] = $row->usercode;
				//echo "<pre>"; print_r($_POST); exit;
				#Check for username exist
				$where = " AND (aadhar LIKE '".$commonobj->getAESCryptData(trim($_POST['aadhar']))."'  OR email LIKE '".$commonobj->getAESCryptData(trim($_POST['email']))."') AND doctorid != ".$_POST['doctorid'];
				if($commonobj->getDoctors($where)) {
					$errormsg = "Aadhar or Email already exist";
				} else {
				
					$insertData = new Default_Models_Doctors($_POST);
					$insertData->save();				
					$this->_redirector->gotoSimple('index','doctors','admin', array('msg' => 'Updated_Successfully'));
				}
			}
		}
		
		#Setting data to view page
		$this->view->row = $row;	
		$this->view->form = $form;		
		$this->view->profileaction = "edit";
		$this->view->errormsg = $errormsg;
	}
	
	public function deleteAction(){
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Disable layout
		$this->_helper->layout()->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		
		if(isset($_GET['rowid']) && $_GET['rowid'] != ""){
			#Getting Objects
			$commonobj = new Default_Models_Common();
			$doctors = new Default_Models_Doctors();
			$row =  $doctors->find($_GET['rowid']);
		
			#Getting doctors list
			$commonobj->deleteDoctors($_GET['rowid'], $row->adminid);
			$this->_redirector->gotoSimple('index','doctors','admin', array('msg' => 'Deleted_Successfully'));
		}
		echo "<br>==========>RowId Not Found";
		exit;	
		
	}
}