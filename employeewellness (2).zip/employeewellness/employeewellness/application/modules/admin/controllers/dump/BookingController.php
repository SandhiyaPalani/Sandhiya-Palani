<?php

class BookingController extends Zend_Controller_Action
{
	protected $_redirector = null;
	protected $_dbAdapter = null;
    
	public function init()
    {
		$registry = Zend_Registry::getInstance();
		$this->_dbAdapter = $registry->dbAdapter;
        $this->_redirector = $this->_helper->getHelper('Redirector');

        if (empty($this->view->adminidentity)) {
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
	    } else {
			$identity = $this->view->adminidentity;
			$userType = $identity->userType;
			if($userType != 'A') {								
				Default_Models_AdminAuth::destroy();
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
			}
		}
	
	}
	
	public function indexAction()
	{
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';		
		
		#Getting doctors info
		$row =  $commonobj->getMyappointments($where);		
		//print_r($row); exit;
		
		#Setting data to view page
		$this->view->row = $row;	
		$this->view->profileaction = "Appointments";
		$this->view->errormsg = $errormsg;
		$this->view->msg = $_GET['msg'];
	}
}