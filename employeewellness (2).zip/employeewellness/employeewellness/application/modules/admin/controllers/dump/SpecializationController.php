<?php

class SpecializationController extends Zend_Controller_Action
{
	protected $_redirector = null;
	protected $_dbAdapter = null;
    
	public function init()
    {
		$registry = Zend_Registry::getInstance();
		$this->_dbAdapter = $registry->dbAdapter;
        $this->_redirector = $this->_helper->getHelper('Redirector');

        if (empty($this->view->adminidentity)) {
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
	    } else {
			$identity = $this->view->adminidentity;
			$userType = $identity->userType;
			if($userType != 'A') {								
				Default_Models_AdminAuth::destroy();
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
			}
		}
	
	}

    public function indexAction()
    {
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#POST Process
		$searchTerm = '';
		if($this->getRequest()->isPost()) {
			$searchTerm = trim($_POST['searchTerm']);
		}		
		
		#Getting users list
		$specialization =  $commonobj->getSpecialization($searchTerm);
		
		#Setting data to view page
		$this->view->specialization = $specialization;
		$this->view->searchTerm = $searchTerm;
		$this->view->msg = str_replace('_', ' ', $_GET['msg']);	
    }

    public function newAction()
    {	
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$form    = new Default_Form_SpecializationForm();
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';
		
		#POST Process
		if($this->getRequest()->isPost()) {			
			if($form->isValid($request->getPost())){
					$insertData = new Default_Models_Specialization($_POST);				
					$insertData->save();
					$this->_redirector->gotoSimple('index','specialization','admin',  array('msg' => 'Specialization_added_successfully'));
			}
		}
		
		#Setting data to view page
		$this->view->profileaction = "add";
		$this->view->form = $form;
		$this->view->errormsg = $errormsg;
    }	
	
	public function editAction()
	{
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$form    = new Default_Form_SpecializationForm();
		$specialization = new Default_Models_Specialization();
		
		#Getting specialization info
		$row =  $specialization->find($_GET['rowid']);
		
		#variables
		$errormsg = '';		
		
		#POST Process
		if($this->getRequest()->isPost()) {
			if($form->isValid($request->getPost())){
				//echo "<pre>"; print_r($_POST); exit;
				
				$insertData = new Default_Models_Specialization($_POST);
				$insertData->save();				
				$this->_redirector->gotoSimple('index','specialization','admin', array('msg' => 'Updated_Successfully'));
			}
		}
		
		#Setting data to view page
		$this->view->row = $row;	
		$this->view->form = $form;		
		$this->view->profileaction = "edit";
		$this->view->errormsg = $errormsg;
	}
	
	public function deleteAction(){
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Disable layout
		$this->_helper->layout()->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		
		if(isset($_GET['rowid']) && $_GET['rowid'] != ""){
			#Getting Objects
			$commonobj = new Default_Models_Common();
		
			#Getting users list
			$commonobj->deleteSpecialization($_GET['rowid']);
			$this->_redirector->gotoSimple('index','specialization','admin', array('msg' => 'Deleted_Successfully'));
		}
		echo "<br>==========>RowId Not Found";
		exit;	
		
	}	
}