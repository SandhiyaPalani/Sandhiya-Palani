<?php

class EmergencyController extends Zend_Controller_Action
{
	protected $_redirector = null;
	protected $_dbAdapter = null;
    
	public function init()
    {
		$registry = Zend_Registry::getInstance();
		$this->_dbAdapter = $registry->dbAdapter;
        $this->_redirector = $this->_helper->getHelper('Redirector');

        if (empty($this->view->adminidentity)) {
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
	    } else {
			$identity = $this->view->adminidentity;
			$userType = $identity->userType;
			if($userType != 'D') {								
				Default_Models_AdminAuth::destroy();
				$this->_redirector->gotoSimple('index','onlinedoctor','admin');
				exit;
			}
		}
	
	}

    public function indexAction()
    {		
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';	
		$row = array();
		$loggeddoctor = $this->view->adminidentity->userName;
		
		#Getting doctors info
		$where = " AND e.`reqdoctorcode` = '".$loggeddoctor."' ";
		$row =  $commonobj->getEmergency($where);		
		
		#Setting data to view page
		$this->view->row = $row;	
		$this->view->profileaction = "Emergency Request";
		$this->view->errormsg = $errormsg;	
		$this->view->msg = $_GET['msg'];
    }

    public function othersAction()
    {		
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';	
		$row = array();
		$loggeddoctor = $this->view->adminidentity->userName;
		
		#Getting doctors info
		$where = " AND e.`doctorcode` = '".$loggeddoctor."' ";
		$row =  $commonobj->getEmergency($where);		
		
		#Setting data to view page
		$this->view->row = $row;	
		$this->view->profileaction = "Emergency Request";
		$this->view->errormsg = $errormsg;	
		$this->view->msg = $_GET['msg'];
    }
	
	public function newAction()
	{
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = $patientcode = '';	
		$doctorlist = array();
		$loggeddoctor = $this->view->adminidentity->userName;
		
		#POST Process
		$searchTerm = $where = '';
		if($this->getRequest()->isPost()) {
			$patientcode = $_POST['patientcode'];
		}	
		
		if($patientcode) {
			$doctorlist = $commonobj->getEmergencyDoctors($patientcode, $loggeddoctor);
		}
		
		if(isset($_GET['rowid']) && !empty($_GET['rowid'])) {
			
			$info = explode("_",$_GET['rowid']);
			#print_r($info);
			
			$data["reqdoctorcode"] = $loggeddoctor; 
			$data["doctorcode"] = $info[0]; 
			$data["patientcode"] = $info[1]; 
			$data["status"] = "Pending"; 
			$empid = $commonobj->bookEmergency($data);
			if($empid){
				
				$where = " AND e.`emid` = '".$empid."' ";
				$empinfo =  $commonobj->getEmergency($where);
				
				//Sendemail
				$fullname = ucfirst($empinfo[0]->rdfiistanme)." ".ucfirst($empinfo[0]->rdlastname);
				$emailinfo = array(
					"fromemail" => $commonobj->getAESCryptData($empinfo[0]->rdemail, 'decrypt'),
					"fromname" =>$fullname,
					"toemail" => $commonobj->getAESCryptData($empinfo[0]->demail, 'decrypt'),#$this->view->testemail,#
					"subject" =>"Emergency Request came for patient code(".$empinfo[0]->uusercode.")",
					"texthtml" =>"Dear <strong>Doctor</strong>,<br><br>
									You have an emergency request from doctor(".$fullname.") for patient code(".$empinfo[0]->uusercode."). Kindly approve the request.
										<br><br>
											Regards,<br>
											<strong>Health Care Admin</strong>",
				 );
				$output = $commonobj->sendtestemail($emailinfo);
					
				
				$this->_redirector->gotoSimple('index','emergency','admin',  array('msg' => 'Emergency_request_sent_successfully'));
			} else {
				$errormsg = "Error in sending request";
			}
		}
		
		#Setting data to view page
		$this->view->profileaction = "New Emergency Request";
		$this->view->doctorlist = $doctorlist;
		$this->view->errormsg = $errormsg;
		$this->view->patientcode = $patientcode;
		$this->view->msg = $_GET['msg'];
	}
	
	public function infoAction()
	{
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = $where = $empcode = '';	
		$appointmentlist = array();
		$loggeddoctor = $this->view->adminidentity->userName;
		
		#POST Process
		if($this->getRequest()->isPost()) {
			$empcode = $_POST['emergencycode'];
			
			$empinfo = $commonobj->checkEmergencyCode($empcode);
			if($empinfo) {
				//print_r($empinfo); exit;
				if($empinfo[0]->reqdoctorcode == $loggeddoctor || $empinfo[0]->doctorcode == $loggeddoctor) {
					if(date("Y-m-d") <= $empinfo[0]->expiry){
						$where = " AND ap.status LIKE 'Closed' AND ap.doctorid = ".$empinfo[0]->requserid;
						$appointmentlist = $commonobj->getMyappointments($where);
					} else {
						$errormsg = "Given emergency code was expired. Kindly request for new code.";
					}
				} else {
					$errormsg = "Sorry you are not having access to view patient information";
				}
			} else {
				$errormsg = "Invalid Emergency Code";
			}			
		}	
		
		#Setting data to view page
		$this->view->profileaction = "View Patient INfo";
		$this->view->appointmentlist = $appointmentlist;
		$this->view->errormsg = $errormsg;
		$this->view->msg = $_GET['msg'];
		$this->view->empcode = $empcode;
	}
	
	public function downloadcsvAction(){
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#Disable layout
		$this->_helper->layout()->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		
		$filename = 'appointmentreport';
		$filepath = 'G:/PleskVhosts/tripletechsoft.in/myshop.tripletechsoft.org/cloudhealthcare/html/images/'. $filename.'.csv';
		
		#echo $filepath;
		//exit;
		$output = fopen($filepath, 'w+');
		
		$empinfo = $commonobj->checkEmergencyCode($_GET['empcode']);
		if($empinfo) {
			$where = " AND ap.status LIKE 'Closed' AND ap.doctorid = ".$empinfo[0]->requserid;
			$appointmentlist = $commonobj->getMyappointments($where);
			#echo "<pre>"; print_r($appointmentlist); exit;
			if($appointmentlist) {
				$inc = 1;
				fputcsv($output, array('Patient', ucfirst($appointmentlist[0]->patientfname)." ".ucfirst($appointmentlist[0]->patientlname)));
				fputcsv($output, array('Doctor', ucfirst($appointmentlist[0]->doctorfname)." ".ucfirst($appointmentlist[0]->doctorlname)));
				fputcsv($output, array());
				fputcsv($output, array());
				fputcsv($output, array('Si. No', 'Appointment Datetime', 'Reason', 'Comments'));
				foreach($appointmentlist as $appoint){
					fputcsv($output, array($inc, $appoint->appointmentdate.' '.$appoint->appointmenttime, $appoint->reason, $appoint->comments));
					$inc++;
				}
			}
		}	
		fclose($output);
		
		header("Content-type: text/csv");
		header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
		header('Content-Length: ' . filesize($filepath)); 
		readfile($filepath);
		
	}
	
	public function approveAction(){
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Disable layout
		$this->_helper->layout()->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		
		if(isset($_GET['rowid']) && $_GET['rowid'] != ""){
			#Getting Objects
			$commonobj = new Default_Models_Common();
		
			#Random code
			$seed = str_split('abcdefghijklmnopqrstuvwxyz'
                 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ');
			shuffle($seed);
			$rand = '';
			foreach (array_rand($seed, 5) as $k) $rand .= $seed[$k];
			
			$info = array(
						"status" => "Approved",
						"expiry" => date("Y-m-d", time() + 86400),
						"code" => strtoupper($rand.date('YmdHsA').rand(100,999)),
						);
			$commonobj->updateEmergency($info, $_GET['rowid']);			
				
			
			$where = " AND e.`emid` = '".$_GET['rowid']."' ";
			$empinfo =  $commonobj->getEmergency($where);
			
			//Sendemail
			$fullname = ucfirst($empinfo[0]->dfirstname)." ".ucfirst($empinfo[0]->dlastname);
			$emailinfo = array(
				"fromemail" => $commonobj->getAESCryptData($empinfo[0]->demail, 'decrypt'),
				"fromname" =>$fullname,
				"toemail" => $commonobj->getAESCryptData($empinfo[0]->rdemail, 'decrypt'), #$this->view->testemail,#
				"subject" =>"Your Emergency Request for patient code(".$empinfo[0]->uusercode.") was approved",
				"texthtml" =>"Dear <strong>Doctor</strong>,<br><br>
								Your emergency request for patient(".$empinfo[0]->uusercode.") was approved by ".$fullname.".
									<br><br>
								Access Code : ".$empinfo[0]->code."<br>
								expire on : ".$empinfo[0]->expiry."<br><br>
										Regards,<br>
										<strong>Health Care Admin</strong>",
			 );
			$output = $commonobj->sendtestemail($emailinfo);
			
			$this->_redirector->gotoSimple('others','emergency','admin', array('msg' => 'Emergency_request_approved_successfully'));
		}
		echo "<br>==========>RowId Not Found";
		exit;	
		
	}
}